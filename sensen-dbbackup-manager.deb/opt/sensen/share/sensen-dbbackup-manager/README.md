
# Installation Instructions

#NOTE: This script can only run for the user - backup.user

# Step#1
Check Python3 is installed in the system using python3 --version
If not installed install using sudo apt-get install python3

# Step#2
Install virutalenv using sudo apt-get install virtualenv

# Step#3
Create virtual env where on which the program has to run

mkdir environments

cd environments

virtualenv --system-site-packages --no-setuptools --python=python3.5  venv


# Step#4

source venv/bin/activate

# Step#5
Now copy the database backup/restore script which should include config, keypass and run file

# Step#6 
pip3 install -r requirements.txt --user

# Step#7 
Now update run script accordingly
(To run manually to test just use python3 db_backup.py || python3 db_restore.py
