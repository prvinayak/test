


#NOTE: This script can only run for the user - backup.user

#Step 1 

Edit db_config.ini accordingly

#Step 2 

Activate virtual envirnoment:- source venv/bin/activate

#Step 3 

run the script :- python pg_backup.py


