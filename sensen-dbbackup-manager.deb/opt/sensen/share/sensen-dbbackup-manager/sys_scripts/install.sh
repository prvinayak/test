#!/bin/bash

sleep 10

##Python and pip


##virutalenv install
pip3 install virtualenv

cd /opt/sensen/share/sensen-dbbackup-manager
virtualenv --system-site-packages --no-setuptools --python=python3  venv

##virtualenv activate
cd /opt/sensen/share/sensen-dbbackup-manager

activate () {
  source /opt/sensen/share/sensen-dbbackup-manager/venv/bin/activate
}

activate



##requirements install

pip3 install -r requirements.txt --user

chown backupadm /opt/sensen/share/sensen-dbbackup-manager
