#!/bin/bash

export PGPASSWORD='sae_nFahB9bp';

cd /home/sensen/mywork/support/General/config-based/
../venv/bin/python3 pg_backup_test.py
