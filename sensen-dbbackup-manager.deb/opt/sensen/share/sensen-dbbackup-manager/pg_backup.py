#!/usr/bin/env python

import os, random, struct
import ast
import sys
import time
import tarfile
import datetime
import calendar
import subprocess
import logging
import paramiko
import pysftp
from os.path import getsize
import logging.handlers as handlers
import configparser
from datetime import date
import smtplib, ssl
import getpass
from shutil import copyfile
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import schedule

config = configparser.RawConfigParser()
config.read('db_config.ini')

date = time.strftime('%d%b%Y')

if getpass.getuser() != "backupadm":
   print ("WRONG USER, your user needs to be :- backupadm for this script")
   exit()

# Start of creating logger
logdir = config.get('DIRECTORY_SETTINGS', 'LOG_PATH')
log_filename = "%s/%s-%s.log" % (logdir, "db-backup", date)

logger = logging.getLogger('DB-BACKUP')
logger.setLevel(logging.INFO)

# Here we define our formatter
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')

logHandler = handlers.TimedRotatingFileHandler(log_filename, when='d', interval=1, backupCount=2)
logHandler.setLevel(logging.INFO)
# Here we set our logHandler's formatter
logHandler.setFormatter(formatter)

logger.addHandler(logHandler)

# End of creating logger


backup_date = time.strftime('%d%b%Y-%H%M%S')

# Loading directory settings from config
secret_key_path = config.get('DIRECTORY_SETTINGS', 'SECRET_KEY_PATH')
root_path = config.get('DIRECTORY_SETTINGS', 'LOCAL_BACKUP_DIR')
remote_root_path = config.get('DIRECTORY_SETTINGS', 'REMOTE_ROOT_PATH')

# Load basic settings from config
host_short_name = config.get('BASIC_SETTINGS', 'HOST_SHORT_NAME')
daily_backup_time = config.get('BASIC_SETTINGS', 'DAILY_BACKUP_TIME')

# Load database settings from config
db_user = config.get('DB_SETTINGS', 'DBUSER')
db_pass = config.get('DB_SETTINGS', 'DBPASS')
db_name = config.get('DB_SETTINGS', 'DBNAME')
db_port = config.get('DB_SETTINGS', 'DBPORT')

# Load backup settings from config
daily_backup = config.getboolean('BACKUP_SETTINGS', 'DAILY_BACKUP')

# Load ftp settings from config
ftp_server = config.get('FTP_SETTINGS', 'FTP_SERVER')
ftp_username = config.get('FTP_SETTINGS', 'FTP_USERNAME')
ftp_password = config.get('FTP_SETTINGS', 'FTP_PASSWORD')
ftp_port = config.get('FTP_SETTINGS', 'FTP_PORT')

#Load Backup Status from config
backup_started = config.get('BACKUP_STATUS', 'BACKUP_STARTED')
backup_success = config.get('BACKUP_STATUS', 'BACKUP_SUCCESS')
backup_failed = config.get('BACKUP_STATUS', 'BACKUP_FAILED')
ftpupload_started = config.get('BACKUP_STATUS', 'FTP_UPLOAD_STARTED')
ftpupload_success = config.get('BACKUP_STATUS', 'FTP_UPLOAD_SUCCESS')
ftpupload_failed = config.get('BACKUP_STATUS', 'FTP_UPLOAD_FAILED')

# Load email settings from config
ssmtpserver = config.get('EMAIL_SENDER', 'SENDER_SERVER')
ssmptport = config.get('EMAIL_SENDER', 'SENDER_PORT')
senderemail = config.get('EMAIL_SENDER', 'EMAIL_USER')
email_password = config.get('EMAIL_SENDER', 'EMAIL_PASSWORD')
email_send = config.get('EMAIL_RECIPIENT', 'RECEIVER_EMAIL')

# Load File Retention Settings from config
daily_backup_retention_days = config.get('RETENTION_SETTINGS', 'DAILY_BACKUP_TO_KEEP')
weekly_backup_retention_days = config.get('RETENTION_SETTINGS', 'WEEKLY_BACKUP_TO_KEEP')
monthly_backup_retention_days = config.get('RETENTION_SETTINGS', 'MONTHLY_BACKUP_TO_KEEP')
yearly_backup_retention_days = config.get('RETENTION_SETTINGS', 'YEARLY_BACKUP_TO_KEEP')

fulldir = root_path + "/" + host_short_name
src_path = fulldir + "/daily/"

remote_path = remote_root_path + "/" + host_short_name
remote_mode_path = remote_path + "/daily/"

now = datetime.datetime.now()

myhost = host_short_name
message = """\
        <!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
</head>

<body style="margin: 0; padding: 0;">
    <table align="center" border="1" cellpadding="0" cellspacing="0" width="650">
        <tr>
            <td align="center" bgcolor="#F2F3F4" style="padding: 40px 0 30px 0;">
                <span><img src="https://www.sensennetworks.com/wp-content/themes/sensen/assets/img/logo.png"
                        alt="sensen_logo" width="200" height="40"></span>
            </td>
        </tr>
        <tr>
            <td bgcolor="#FFFFFF" style="padding: 40px 30px 40px 30px;">
                <table border="1" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td style="padding-left: 10px;">
                            <h3>{0} Database Backup Notification</h3>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0 10px 10px;">
                            <p>Scheduled {0} database backup {1} </p>
                            <p>Server Initated: {2} </p>
                            <p>Timestamp: {3}</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table border="1" cellpadding="0" cellspacing="0" width="100%">
                                <tr>
                                    <td width="300" valign="center" style="padding-left:10px;">
                                        {4}
                                    </td>
                                    <td width="300" valign="center" style="padding-left:10px;">
                                        {5}
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td align="center" bgcolor="#7DCEA0" valign="center" style="padding: 30px 30px 30px 30px;">
                <p style="color:black">This is an automatically generated email â€“ please do not reply to it.</p>
            </td>
        </tr>
    </table>
</body>
</html>
        """

if not os.path.exists(logdir):
    os.mkdir(logdir)

def getSize(filepath, unit = "MB"):
    bit_shift = {"B":0, "kb":7, "KB":10, "mb":17, "MB":20, "gb":27, "GB":30, "TB":40}
    return '{:,.0f}'.format(getsize(filepath)/float(1<<bit_shift[unit]))+" "+unit

def format_email(backup_type, backup_status, backup_host, backup_time, backup_file, backup_file_size):
    backup_time = time.strftime('%A, %B %d, %Y %H:%M:%S')
    if(backup_file != ""):
        backup_filename = "<p>Backup File Name: {0} </p>".format(backup_file)
        backup_filesize = "<p>Backup File Size: {0} </p>".format(backup_file_size)
        formatted_message = message.format(backup_type, backup_status, backup_host, backup_time, backup_filename, backup_filesize)
    else:
        formatted_message = message.format(backup_type, backup_status, backup_host, backup_time, "", "")
    return formatted_message

def send_email(backup_status, backup_host, backup_time, backup_file, backup_file_size):

        backup_type = "Daily"
        context = ssl.create_default_context()
        msg = MIMEMultipart("alternative")
        msg["Subject"] = "{0} - {1} DATABASE BACKUP STATUS".format(host_short_name, backup_type.upper())
        msg["From"] = senderemail
        msg['To'] = email_send
        # Try to log in to server and send email
        # Turn these into plain/html MIMEText objects
        body = MIMEText(format_email(backup_type, backup_status, backup_host, backup_time, backup_file, backup_file_size), 'html')

        msg.attach(body)
        server = smtplib.SMTP(ssmtpserver, ssmptport)
        server.starttls()
        server.login(senderemail,email_password)
        try:
            server.sendmail(senderemail,email_send.split(','), msg.as_string())
        finally:
            server.quit()


def create_dir_sftp():

    transport = paramiko.Transport((ftp_server, int(ftp_port)))
    transport.connect(username=ftp_username, password=ftp_password)
    sftp = paramiko.SFTPClient.from_transport(transport)


    try:
        sftp.chdir(remote_path)  # Test if remote_path exists
    except IOError:
        sftp.mkdir(remote_path)  # Create remote_path
        logger.info("directory created", remote_path)
    try:
        sftp.chdir(remote_mode_path)
    except IOError:
        sftp.mkdir(remote_mode_path)
        logger.info("directory created", remote_mode_path)
    sftp.close()
    time.sleep(10)


def lcs(string_one,string_two):
    m = len(string_one)
    n = len(string_two)
    counter = [[0]*(n+1) for x in range(m+1)]
    longest = 0
    lcs_set = set()
    for i in range(m):
        for j in range(n):
            if string_one[i] == string_two[j]:
                c = counter[i][j] + 1
                counter[i+1][j+1] = c
                if c > longest:
                    lcs_set = set()
                    longest = c
                    lcs_set.add(string_one[i-c+1:i+1])
                elif c == longest:
                    lcs_set.add(string_one[i-c+1:i+1])

    return lcs_set


def delete_sftp_old_files():

        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        with pysftp.Connection(ftp_server, username=ftp_username, password=ftp_password, port=int(ftp_port), cnopts=cnopts) as sftp:

             sftp.chdir(remote_mode_path)
             for f in sftp.listdir(remote_mode_path):
               file_date = lcs(f, date)
               for s in file_date:
                  if s != date:
                    sftp.unlink(remote_mode_path+f)
                    logger.info("File deleted: %s",remote_mode_path+f)

        sftp.close()
        time.sleep(10)

def sftp_upload(backup_type, myhost, backup_date, _filename, file_size):
    try:
        create_dir_sftp()
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        with pysftp.Connection(ftp_server, username=ftp_username, password=ftp_password, port=int(ftp_port), cnopts=cnopts) as sftp:
            logger.info("Connection succesfully stablished ... ")
            sftp.chdir(remote_mode_path)
            sftp.put(src_path+_filename, remote_mode_path+_filename)
            time.sleep(10)
            sftp.close()
            send_email(ftpupload_success, myhost, backup_date,  _filename, file_size)
            logger.info("Scheduled backup file successfully uploaded to backup server through sftp")
    except:
        logger.error("Failed to upload to Backup server")
        send_email(ftpupload_failed, myhost, backup_date,  _filename, file_size)
        logger.info("Scheduled backup file failed to uploaded to backup server through sftp")

def perform_backup():
    myhost = os.uname()[1]

    # sending backup started email
    send_email(backup_started, myhost, backup_date, "", "" )
    logger.info("Scheduled Database backup is in initiated for the host {0}".format(myhost))

    if not os.path.exists(fulldir):
        os.mkdir(fulldir)

    temp_backup_file_path = "%s%s-%s.sql" % (fulldir+"/", host_short_name, backup_date)
    backup_file_name = "%s-%s.sql" % (host_short_name, backup_date)

    # condition to check backup command is successfully executed
    subprocess.call("pg_dump -U {0} -d {1} -f {2} ".format(db_user, db_name, temp_backup_file_path), shell=True)
    logger.info("Scheduled database backup is sucessfull for the host {0}".format(host_short_name))
    # sending backup success email
    logger.info("Started compressing Database Backup file")
    compress_file_name = temp_backup_file_path+".tar.gz"
    # Formatting Command to compres database backup
    logger.info("{0} Database Backup file started Archiving".format(host_short_name))
    time.sleep(5)
    compress_string = "tar -cvzf {0} {1}".format(compress_file_name, temp_backup_file_path)
    logger.info("{0} database backup file is compressed".format(host_short_name))
    # execute the compress command using subprocess
    time.sleep(10)
    subprocess.call(compress_string, shell=True)
    # Encrypt database backup
    backup_filename_encrypt = temp_backup_file_path+".tar.gz.dat"
    encrypt_string = "openssl enc -aes-256-cbc -in {0} -out {1} -pass file:{2}".format(compress_file_name, backup_filename_encrypt, secret_key_path)
    subprocess.call(encrypt_string, shell=True)
    file_size = getSize(backup_filename_encrypt)
    _filename = backup_file_name + ".tar.gz.dat"
    send_email(backup_success, myhost, backup_date, _filename, file_size)
    # Check daily backup is enabled
    if daily_backup == True:
        remote_path = remote_root_path + "/{0}/daily/".format(host_short_name)
        full_path = fulldir + "/daily/"
        if not os.path.exists(full_path):
            os.mkdir(full_path)
        copyfile(backup_filename_encrypt, full_path+_filename)
        send_email(ftpupload_started, myhost, backup_date, _filename, file_size)
        sftp_upload("Daily", myhost, backup_date,  _filename, file_size)
        print (_filename)

    # Remove uncompressed file
    if os.path.isfile(backup_filename_encrypt):
        os.remove(temp_backup_file_path)
    else:    ## Show an error ##
        logger.error("{0} file not found".format(temp_backup_file_path))

    if os.path.isfile(compress_file_name):
        os.remove(compress_file_name)
    else:    ## Show an error ##
        logger.error("{0} file not found".format(compress_file_name))

    if os.path.isfile(backup_filename_encrypt):
        os.remove(backup_filename_encrypt)
    else:    ## Show an error ##
        logger.error("{0} file not found".format(backup_filename_encrypt))

def delete_old_files():
        daily_file_path = fulldir + "/daily/"
        current_time = time.time()
        for f in os.listdir(daily_file_path):
            creation_time = os.path.getctime(daily_file_path+f)
            if (current_time - creation_time) // (24 * 3600) >= float(daily_backup_retention_days):
                os.unlink(daily_file_path+f)
                logger.info('{} removed'.format(daily_file_path+f))

# Main Function

def main():
        schedule.every(1).days.at(daily_backup_time).do(perform_backup)
        schedule.every(1).days.at(daily_backup_time).do(delete_sftp_old_files)
        schedule.every(1).days.at(daily_backup_time).do(delete_old_files)
        while True:
          schedule.run_pending()
          time.sleep(1)

if __name__ == '__main__':
    main()

